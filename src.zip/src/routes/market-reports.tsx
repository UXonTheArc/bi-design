import { createFileRoute } from '@tanstack/react-router'
import MarketReport from '@/components/market-report'

export const Route = createFileRoute('/market-reports')({
  component: MarketReport,
})
